Author: Yogesh singh
Author URL: https://makitweb.com/
Author Email: makitweb@gmail.com
Tutorial Link: https://makitweb.com/date-range-search-in-datatable-with-jquery-ajax-and-php/

Instructions - 
1. Import employee.sql table in your MySQL database.
2. Update config.php file.

